<?php

$_['heading_total'] = 'Итого';
$_['text_free'] = 'Бесплатно';