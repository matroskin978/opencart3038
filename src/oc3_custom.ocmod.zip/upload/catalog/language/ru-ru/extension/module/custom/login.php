<?php

$_['heading_login'] = 'Оформить заказ как';

$_['text_auth'] = 'Уже зарегистрирован';
$_['text_register'] = 'Зарегистрироваться';
$_['text_guest'] = 'Гость';
$_['text_forgotten'] = 'Забыли пароль?';
$_['text_loading'] = 'Загрузка';
$_['entry_email'] = 'E-mail';
$_['entry_password'] = 'Пароль';
$_['button_login'] = 'Войти';