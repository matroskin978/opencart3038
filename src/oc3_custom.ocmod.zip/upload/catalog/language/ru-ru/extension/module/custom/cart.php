<?php

$_['heading_cart'] = 'Корзина';
$_['column_image'] = 'Изображение';
$_['column_name'] = 'Название товара';
$_['column_model'] = 'Модель';
$_['column_sku'] = 'Артикул';
$_['column_quantity'] = 'Количество';
$_['column_price'] = 'Цена';
$_['column_total'] = 'Всего';
$_['column_remove'] = 'Удалить';

$_['text_products_total'] = 'Итого';

$_['button_update'] = 'Обновить';
$_['button_remove'] = 'Удалить';
$_['button_clear']  = 'Очистить корзину';