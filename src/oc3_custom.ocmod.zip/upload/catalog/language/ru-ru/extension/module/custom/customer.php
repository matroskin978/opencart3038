<?php

$_['heading_customer'] = 'Личные данные';

$_['entry_customer_group'] = 'Группа покупателя';
$_['entry_firstname'] = 'Имя';
$_['entry_lastname'] = 'Фамилия';
$_['entry_email'] = 'Email';
$_['entry_telephone'] = 'Телефон';
$_['entry_fax'] = 'Факс';
$_['entry_password'] = 'Пароль';
$_['entry_confirm'] = 'Подтверждение пароля';
$_['button_upload'] = 'Загрузить';

$_['error_firstname'] = 'Не корректно заполнено Имя';
$_['error_lastname'] = 'Не корректно заполнено Фамилия';
$_['error_email'] = 'Не корректно заполнено Email';
$_['error_telephone'] = 'Не корректно заполнено Телефон';
$_['error_fax'] = 'Не корректно заполнено Факс';
$_['error_password'] = 'Введите пароль';
$_['error_confirm'] = 'Пароли не совпадают';
$_['error_custom_field'] = 'Не корректно заполнено %s';