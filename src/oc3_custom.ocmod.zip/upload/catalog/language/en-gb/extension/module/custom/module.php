<?php

$_['heading_module'] = 'Additional features';