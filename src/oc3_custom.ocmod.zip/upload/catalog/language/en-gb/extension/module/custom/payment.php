<?php

$_['heading_payment'] = 'Payment';
$_['error_no_payment'] = 'There are no payment options available';

$_['error_payment1'] = 'The payment method is not selected';
$_['error_payment2'] = 'This payment method was not found';
$_['error_agree'] = 'No agreement condition selected';