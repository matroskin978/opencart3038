<?php

$_['heading_total'] = 'Totals';
$_['text_free'] = 'Free';