<?php

$_['error_stock'] = 'Products marked with *** are not available in the right quantity or they are not available!';
$_['error_minimum'] = 'The minimum quantity of goods for order %s equals %s!';